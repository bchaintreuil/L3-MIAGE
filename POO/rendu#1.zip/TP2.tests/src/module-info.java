module tp2.tests {
	requires junit;
	requires tp2.rendu;
	requires uca.l3.helper.test;
	requires uca.l3.helper.complexity;
}