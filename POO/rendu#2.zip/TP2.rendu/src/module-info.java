module tp2.rendu {
	exports tp2.rendu;
}