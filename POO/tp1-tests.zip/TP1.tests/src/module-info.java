module tp1.tests {
	requires java.desktop;
	requires junit;
	requires uca.l3.helper.test;
	requires uca.l3.helper.swing;
	requires tp1;
}