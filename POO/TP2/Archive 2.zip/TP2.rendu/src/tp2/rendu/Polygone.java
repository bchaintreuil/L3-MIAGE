/**
 * 
 */
package tp2.rendu;

import java.util.ArrayList;

/**
 * @author Benjamin CHAINTREUIL
 * @author Thomas DELMARE
 *
 */

public class Polygone {
    // Constructor and constructor variables
	public Vecteur[] points;
		
	public Polygone(Vecteur... points) {
		this.points = new Vecteur[points.length];
		System.arraycopy(points, 0, this.points, 0, points.length);
	}


	// Main / Tests

	public static void main(String[] args) {		
		Polygone unPolygone = new Polygone(new Vecteur(0.0, 0.0), new Vecteur(0.0, 1.0), new Vecteur(1.0, 1.0), new Vecteur(1.0, 0.0));
		
		// Test Add Point
		/*unPolygone = unPolygone.setPoint(new Vecteur(0.0, 0.0));
		if(unPolygone.points.length == 5){
			System.out.println("Test ajout point réussi");
		}
		else{
			System.out.println("Test ajout point échoué");
		}*/
		
		ArrayList<Triangle> liste_triangles = new ArrayList<Triangle>();
		liste_triangles = Polygone.trianguler(unPolygone, liste_triangles);
		
		Triangle[] list = new Triangle[liste_triangles.size()];
		list = liste_triangles.toArray(list);
		
		for(int i = 0; i < list.length; i++) {
			System.out.println("Triangle n°" + (i+1));
			list[i].OA.print();
			list[i].OB.print();
			list[i].OC.print();
		}
		// Test Barycentre		
/*		var barycentre = unPolygone.barycentre();
		if(barycentre.get(0) == 0.5 && barycentre.get(1) == 0.5){
			System.out.println("Test barycentre réussi");	
		}
		else{
			System.out.println("Test barycentre échoué");
		}*/

		// Test périmètre
		var perimetre = unPolygone.perimetre();
		if(perimetre == 4){
			System.out.println("Test perimètre réussi");	
		}
		else{
			System.out.println("Test périmètre échoué");
		}

		// Test trianguler
		//Triangle[] trianglesFromPolygone = trianguler(unPolygone, trianglesFromPolygone);

		//if(trianglesFromPolygone.length == unPolygone.points.length-2 ){
		//	System.out.println("Test trianguler réussi");	
		//}
		//else{
		//	System.out.println("Test trianguler échoué");
		//}
	}

	// Getters and setters

	public Vecteur getPoint(int i) throws RuntimeException{
		if (i > points.length) {
			throw new RuntimeException("i > nbr de points");
		} else {
			return points[i];
		}
	}

	public Polygone setPoint(Vecteur... points) {
		Vecteur[] new_points = new Vecteur[points.length + this.points.length];
		System.arraycopy(this.points, 0, new_points, 0, this.points.length);
		System.arraycopy(points, 0, new_points, this.points.length, points.length);
		return new Polygone(new_points);
	}
	
	// Methods

	public Vecteur barycentre() {
		double[] coordonnees = new double[points[0].dimension()];
		double tempTotal = 0;
		
		for(int i=0;i<points[0].dimension();i++) {
			tempTotal=0;
			for(int j=0;j<points.length ;i++) {
				tempTotal += points[j].get(i);
			}			
		}
		
		for(int k=0; k<coordonnees.length; k++) {
			coordonnees[k]=coordonnees[k]/points.length;
		}	
		
		return new Vecteur(coordonnees);
	}
	
	public double perimetre() {
		double perimetre = 0;
		
		for(int i = 0; i < points.length; i++) {
			if (i < points.length - 1) {
				perimetre += Vecteur.add(points[i], points[i+1].opposé()).length();
			} else {
				System.out.println(points[0].toString());
				perimetre += Vecteur.add(points[i], points[0].opposé()).length();
			}
		}
		return perimetre;
	}
	
	private static int sommet_gauche(Polygone polygone) {
		int n = polygone.points.length;
		double x = polygone.points[0].get(0);
		int k = 0;
		for(int i = 1; i < n; i++) {
			if(polygone.points[i].get(0) < x) {
				x = polygone.points[i].get(0);
				k = i;
			}
		}
		return k;
	}

	private static int voisin_sommet(int nbrPoints, int indice, int dep) {
		int foo = (indice + dep) % nbrPoints;
		if (foo == -1) {
			foo += nbrPoints;
		}
		return foo;
	}

	private static double produit_vect_Z (Vecteur P0, Vecteur P1, Vecteur PM) {
		return (P1.get(0) - P0.get(0)) * (PM.get(1) - P0.get(1)) - (P1.get(1) - P0.get(1)) * (PM.get(0) - P0.get(0));
	}

	private static boolean point_dans_triangle(Vecteur P0, Vecteur P1, Vecteur P2, Vecteur M) {
		return produit_vect_Z(P0, P1, M) > 0 && produit_vect_Z(P1, P2, M) > 0 && produit_vect_Z(P2, P0, M) > 0;
	}

	private static int indice_sommet_distance_max(Polygone polygone, Vecteur P0, Vecteur P1, Vecteur P2, int indice_P0, int indice_P1, int indice_P2) {
		int n = polygone.points.length;
		double distance = 0.0;
		int j = -1;

		for(int i = 0; i < n; i++) {
			if (i != indice_P0 && i != indice_P1 && i != indice_P2) {
				Vecteur M = polygone.points[i];
				if (point_dans_triangle(P0, P1, P2, M)) {
					double d = Math.abs(produit_vect_Z(P1, P2, M));
					if (d > distance) {
						distance = d;
						j = i;
					}
				}
			}
		}
		return j;
	}

	private static Polygone new_polygone(Polygone polygone, int i_start, int i_end) {
		int n = polygone.points.length;
		ArrayList<Vecteur> points = new ArrayList<Vecteur>();
		int i = i_start;
		while(i != i_end) {
			points.add(polygone.points[i]);
			i = voisin_sommet(n, i, 1);
		}
		points.add(polygone.points[i_end]);

		Vecteur[] p = new Vecteur[points.size()];
		p = points.toArray(p);
		return new Polygone(p);
	}
	
	public static ArrayList<Triangle> trianguler(Polygone polygone, ArrayList<Triangle> liste_triangles) {
		int n = polygone.points.length;

		int indice_P0 = sommet_gauche(polygone);
		int indice_P1 = voisin_sommet(n, indice_P0, 1);
		int indice_P2 = voisin_sommet(n, indice_P0, -1);
		
		Vecteur P0 = polygone.points[indice_P0];
		Vecteur P1 = polygone.points[indice_P1];
		Vecteur P2 = polygone.points[indice_P2];

		int j = indice_sommet_distance_max(polygone, P0, P1, P2, indice_P0, indice_P1, indice_P2);
		if (j == -1) {
			liste_triangles.add(new Triangle(P0, P1, P2));
			Polygone polygone_1 = new_polygone(polygone, indice_P1, indice_P2);
			if (polygone_1.points.length == 3) {
				liste_triangles.add(new Triangle(polygone_1.getPoint(0), polygone_1.getPoint(1), polygone_1.getPoint(2)));
			} else {
				trianguler(polygone_1, liste_triangles);
			}
		} else {
			Polygone polygone_1 = new_polygone(polygone, indice_P0, j);
			Polygone polygone_2 = new_polygone(polygone, j, indice_P0);
			
			if (polygone_1.points.length == 3) {
				liste_triangles.add(new Triangle(polygone_1.getPoint(0), polygone_1.getPoint(1), polygone_1.getPoint(2)));
			} else {
				trianguler(polygone_1, liste_triangles);
			}

			if (polygone_2.points.length == 3) {
				liste_triangles.add(new Triangle(polygone_2.getPoint(0), polygone_2.getPoint(1), polygone_2.getPoint(2)));
			} else {
				trianguler(polygone_2, liste_triangles);
			}
		}
		return liste_triangles;
	}
}
