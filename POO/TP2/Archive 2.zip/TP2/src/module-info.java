/**
 * 
 */
/**
 * @author benchai
 *
 */
module tp2 {
	exports tp2.vecteur;
}